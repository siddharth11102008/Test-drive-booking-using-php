<?php include("header.php");

$user_id = $_SESSION['user_id'];
?>

<div class="card">
<h3>My Bookings</h3>

<table>
<tr>
<th>Vehicle</th>
<th>Date</th>
<th>Time</th>
<th>Status</th>
<th>Feedback</th>
<th>Review</th>
</tr>

<?php
$q = mysqli_query($conn,"
SELECT b.*,v.vehicle_name 
FROM test_drive_bookings b
JOIN vehicles v ON b.vehicle_id=v.id
WHERE b.user_id=$user_id
ORDER BY b.id DESC
");

while($r=mysqli_fetch_assoc($q)){

    $feedback = $r['feedback'] ? $r['feedback'] : 'Not Given';
    $review   = $r['feedback_text'] ? $r['feedback_text'] : '-';

    $action = "";

    if($r['status'] == 'completed' && empty($r['feedback'])){
        $action = "
        <form method='post' action='give_feedback.php'>
            <input type='hidden' name='id' value='{$r['id']}'>
            
            <select name='feedback' required>
                <option value=''>Select</option>
                <option value='interested'>Interested</option>
                <option value='not_interested'>Not Interested</option>
            </select>
            
            <textarea name='feedback_text' placeholder='Write your opinion...' required></textarea>
            
            <button type='submit' class='btn btn-approve'>Submit</button>
        </form>
        ";
    }

    echo "<tr>
    <td>{$r['vehicle_name']}</td>
    <td>{$r['booking_date']}</td>
    <td>{$r['booking_time']}</td>
    <td>{$r['status']}</td>
    <td>$feedback</td>
    <td>$review</td>
    
    </tr>";
}
?>
</table>
</div>

<?php include("footer.php"); ?>