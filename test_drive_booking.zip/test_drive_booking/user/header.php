<?php
session_start();
include("../includes/db.php");

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}
?>

<link rel="stylesheet" href="../assets/css/style.css">

<div class="container">

<div class="sidebar">
    <h2>User</h2>
    <a href="index.php">Dashboard</a>
    <a href="vehicles.php">Vehicles</a>
    <a href="my_bookings.php">My Bookings</a>
    <a href="../logout.php">Logout</a>
</div>

<div class="main">