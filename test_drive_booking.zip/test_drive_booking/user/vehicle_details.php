<?php include("header.php");

$id = $_GET['id'];
$r = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM vehicles WHERE id=$id"));
?>

<div class="card">
<h3>Vehicle Details</h3>

<p><b>Name:</b> <?php echo $r['vehicle_name']; ?></p>
<p><b>Brand:</b> <?php echo $r['brand']; ?></p>
<p><b>Model:</b> <?php echo $r['model']; ?></p>
<p><b>Number plate:</b> <?php echo $r['number_plate']; ?></p>
<p><b>Price:</b> ₹<?php echo $r['price']; ?></p>

<?php if($r['image']){ ?>
<img src="../uploads/<?php echo $r['image']; ?>" width="200">
<?php } ?>

<br><br>

<a class="btn btn-add" href="book_test_drive.php?id=<?php echo $r['id']; ?>">Book Test Drive</a>
</div>

<?php include("footer.php"); ?>