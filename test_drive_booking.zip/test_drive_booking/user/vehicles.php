<?php include("header.php"); ?>

<div class="card">
<h3>Available Vehicles</h3>

<table>
<tr>
    <th>Name</th>
    <th>Brand</th>
    <th>Action</th>
</tr>

<?php
$q = mysqli_query($conn,"SELECT * FROM vehicles WHERE status='available'");

while($r=mysqli_fetch_assoc($q)){
echo "<tr>
<td>{$r['vehicle_name']}</td>
<td>{$r['brand']}</td>
<td>
<a class='btn btn-add' href='vehicle_details.php?id={$r['id']}'>View</a>
</td>
</tr>";
}
?>
</table>
</div>

<?php include("footer.php"); ?>