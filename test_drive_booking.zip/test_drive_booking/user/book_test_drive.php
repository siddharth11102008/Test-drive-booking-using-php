<?php include("header.php");

$vehicle_id = $_GET['id'];
$user_id = $_SESSION['user_id'];
?>

<div class="card">
<h3>Book Test Drive</h3>

<form method="post">
    <label>Date</label>
    <input type="date" name="date" required>

    <label>Time</label>
    <input type="time" name="time" required>

    <label>Message</label>
    <textarea name="message"></textarea>

    <button class="btn btn-add" name="book">Book Now</button>
</form>

<?php
if(isset($_POST['book'])){
    $date = $_POST['date'];
    $time = $_POST['time'];
    $msg  = $_POST['message'];

    mysqli_query($conn,"INSERT INTO test_drive_bookings
    (user_id,vehicle_id,booking_date,booking_time,message)
    VALUES('$user_id','$vehicle_id','$date','$time','$msg')");

    echo "<p style='color:green;'>Booking Submitted!</p>";
}
?>
</div>

<?php include("footer.php"); ?>