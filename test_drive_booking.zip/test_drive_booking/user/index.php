<?php include("header.php"); ?>

<div class="card">
    <h3>Welcome <?php echo $_SESSION['name']; ?></h3>
    <p>Book your test drive easily 🚗</p>
</div>

<?php include("footer.php"); ?>