<?php
include("../includes/db.php");

$id = $_POST['id'];
$feedback = $_POST['feedback'];
$text = $_POST['feedback_text'];

mysqli_query($conn,"UPDATE test_drive_bookings 
SET feedback='$feedback', feedback_text='$text'
WHERE id=$id");

header("Location: my_bookings.php");
?>