<?php
session_start();
include("../includes/db.php");

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login.php");
    exit();
}
?>

<link rel="stylesheet" href="../assets/css/style.css">

<div class="container">

<div class="sidebar">
    <h2>Admin</h2>
    <a href="dashboard.php">Dashboard</a>
    <a href="manage_users.php">Users</a>
    <a href="manage_vehicles.php">Vehicles</a>
    <a href="manage_bookings.php">Bookings</a>
    <a href="feedback.php">Feedback</a>
    <a href="admin_logs.php">Logs</a>
    <a href="../logout.php">Logout</a>
</div>

<div class="main">