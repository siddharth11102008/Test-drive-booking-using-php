<?php include("header.php"); ?>

<div class="card">
<h3>Dashboard</h3>

<?php
$users = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users"));
$vehicles = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM vehicles"));
$bookings = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM test_drive_bookings"));
?>

<p>Total Users: <?php echo $users; ?></p>
<p>Total Vehicles: <?php echo $vehicles; ?></p>
<p>Total Bookings: <?php echo $bookings; ?></p>
</div>

<?php include("footer.php"); ?>