<?php include("header.php"); ?>

<div class="card">
<h3>Users</h3>

<table>
<tr>
<th>Name</th>
<th>Email</th>
<th>Role</th>
</tr>

<?php
$q = mysqli_query($conn,"SELECT * FROM users");

while($r=mysqli_fetch_assoc($q)){
    echo "<tr>
    <td>{$r['name']}</td>
    <td>{$r['email']}</td>
    <td>{$r['role']}</td>
    </tr>";
}
?>
</table>
</div>

<?php include("footer.php"); ?>