<?php include("header.php");

$id = $_GET['id'];
$r = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM vehicles WHERE id=$id"));
?>

<div class="card">
<h3>Edit Vehicle</h3>

<form method="post" enctype="multipart/form-data">

<input type="text" name="name" value="<?php echo $r['vehicle_name']; ?>">
<input type="text" name="brand" value="<?php echo $r['brand']; ?>">
<input type="text" name="model" value="<?php echo $r['model']; ?>">
<input type="text" name="price" value="<?php echo $r['price']; ?>">

<!-- Show current image -->
<p>Current Image:</p>
<img src="../uploads/<?php echo $r['image']; ?>" width="120">

<!-- Upload new image -->
<input type="file" name="image">

<button class="btn btn-edit" name="update">Update</button>
</form>

<?php
if(isset($_POST['update'])){

    $name  = $_POST['name'];
    $brand = $_POST['brand'];
    $model = $_POST['model'];
    $price = $_POST['price'];

    $image = $r['image']; // default old image

    // If new image uploaded
    if(!empty($_FILES['image']['name'])){

        // Delete old image (optional but good)
        if(file_exists("../uploads/".$r['image'])){
            unlink("../uploads/".$r['image']);
        }

        $new_image = time() . "_" . $_FILES['image']['name'];
        $tmp = $_FILES['image']['tmp_name'];

        move_uploaded_file($tmp, "../uploads/".$new_image);

        $image = $new_image;
    }

    mysqli_query($conn,"UPDATE vehicles SET
    vehicle_name='$name',
    brand='$brand',
    model='$model',
    price='$price',
    image='$image'
    WHERE id=$id");

    header("Location: manage_vehicles.php");
}
?>
</div>

<?php include("footer.php"); ?>