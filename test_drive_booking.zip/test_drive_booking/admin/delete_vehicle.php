<?php
include("header.php");

$id=$_GET['id'];
mysqli_query($conn,"DELETE FROM vehicles WHERE id=$id");

header("Location: manage_vehicles.php");
?>