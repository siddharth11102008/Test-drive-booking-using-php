<?php include("header.php"); ?>

<div class="card">
<h3>User Feedback</h3>

<table>
<tr>
<th>User</th>
<th>Vehicle</th>
<th>Date</th>
<th>Status</th>
<th>Feedback</th>
<th>Review</th>
</tr>

<?php

$q = mysqli_query($conn,"
SELECT b.*, u.name, v.vehicle_name 
FROM test_drive_bookings b
JOIN users u ON b.user_id = u.id
JOIN vehicles v ON b.vehicle_id = v.id
WHERE b.feedback IS NOT NULL
ORDER BY b.id DESC
");

while($r = mysqli_fetch_assoc($q)){

    // Feedback styling
    if($r['feedback'] == 'interested'){
        $feedback = "<span style='color:green;font-weight:bold;'>Interested</span>";
    } else {
        $feedback = "<span style='color:red;font-weight:bold;'>Not Interested</span>";
    }

    // Review text
    $review = !empty($r['feedback_text']) ? $r['feedback_text'] : '-';

    echo "<tr>
    <td>{$r['name']}</td>
    <td>{$r['vehicle_name']}</td>
    <td>{$r['booking_date']}</td>
    <td>{$r['status']}</td>
    <td>$feedback</td>
    <td>$review</td>
    </tr>";
}
?>

</table>
</div>

<?php include("footer.php"); ?>