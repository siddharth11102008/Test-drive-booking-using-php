<?php
include("../includes/db.php");

$id = $_GET['id'];
$status = $_GET['status'];

mysqli_query($conn,"UPDATE test_drive_bookings 
SET status='$status' WHERE id=$id");

header("Location: manage_bookings.php");
?>