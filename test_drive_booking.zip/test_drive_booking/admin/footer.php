</div> <!-- main -->
</div> <!-- container -->

<div class="footer">
    <p>© Test Drive Booking System</p>
</div>