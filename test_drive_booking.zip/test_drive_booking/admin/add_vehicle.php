<?php include("header.php"); ?>

<div class="card">
<h3>Add Vehicle</h3>

<form method="post" enctype="multipart/form-data">
    
    <input type="text" name="name" placeholder="Vehicle Name" required>
    
    <input type="text" name="brand" placeholder="Brand" required>
    
    <input type="text" name="model" placeholder="Model" required>
    
    <input type="text" name="price" placeholder="Price" required>

    <input type="text" name="number_plate" placeholder="Number Plate (GJ01AB1234)" required>

    <textarea name="description" placeholder="Description"></textarea>

    <label>Select Vehicle Image</label>
    <input type="file" name="image" required>

    <button class="btn btn-add" name="add">Add Vehicle</button>
</form>

<?php
if(isset($_POST['add'])){

    $name = $_POST['name'];
    $brand = $_POST['brand'];
    $model = $_POST['model'];
    $price = $_POST['price'];
    $number_plate = $_POST['number_plate'];
    $description = $_POST['description'];

    /* IMAGE UPLOAD */
    $image = $_FILES['image']['name'];
    $tmp   = $_FILES['image']['tmp_name'];

    /* Rename image to avoid duplicate */
    $new_image = time() . "_" . $image;

    /* Move to uploads folder */
    move_uploaded_file($tmp, "../uploads/" . $new_image);

    /* INSERT INTO DATABASE */
    mysqli_query($conn,"INSERT INTO vehicles
    (vehicle_name, brand, model, price, number_plate, description, image)
    VALUES
    ('$name','$brand','$model','$price','$number_plate','$description','$new_image')");

    echo "<p style='color:green;'>Vehicle Added Successfully</p>";
}
?>

</div>

<?php include("footer.php"); ?>