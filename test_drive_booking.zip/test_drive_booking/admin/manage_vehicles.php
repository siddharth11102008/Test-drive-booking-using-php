<?php include("header.php"); ?>

<div class="card">
<h3>Vehicles</h3>

<a class="btn btn-add" href="add_vehicle.php">Add Vehicle</a>

<table>
<tr>
<th>Name</th>
<th>Brand</th>
<th>Action</th>
</tr>

<?php
$q=mysqli_query($conn,"SELECT * FROM vehicles");

while($r=mysqli_fetch_assoc($q)){
echo "<tr>
<td>{$r['vehicle_name']}</td>
<td>{$r['brand']}</td>
<td>
<a class='btn btn-edit' href='edit_vehicle.php?id={$r['id']}'>Edit</a>
<a class='btn btn-delete' href='delete_vehicle.php?id={$r['id']}' onclick='return confirm(\"Delete?\")'>Delete</a>
</td>
</tr>";
}
?>
</table>
</div>

<?php include("footer.php"); ?>