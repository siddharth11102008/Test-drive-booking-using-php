<?php include("header.php"); ?>

<div class="card">
<h3>Admin Logs</h3>

<table>
<tr>
<th>Admin</th>
<th>Action</th>
<th>Date</th>
</tr>

<?php
$q=mysqli_query($conn,"
SELECT l.*,u.name FROM admin_logs l
JOIN users u ON l.admin_id=u.id
ORDER BY l.id DESC
");

while($r=mysqli_fetch_assoc($q)){
echo "<tr>
<td>{$r['name']}</td>
<td>{$r['action']}</td>
<td>{$r['created_at']}</td>
</tr>";
}
?>
</table>
</div>

<?php include("footer.php"); ?>