<?php
include("../includes/db.php");   // DB connection
include("header.php");           // header
?>
<div class="card">
<h3>Bookings</h3>

<table>
<tr>
<th>User</th>
<th>Vehicle</th>
<th>Date</th>
<th>Status</th>
<th>Action</th>
<th>Feedback</th>
<th>Review</th>
</tr>

<?php

$q=mysqli_query($conn,"
SELECT b.*,u.name,v.vehicle_name 
FROM test_drive_bookings b
JOIN users u ON b.user_id=u.id
JOIN vehicles v ON b.vehicle_id=v.id
");

while($r=mysqli_fetch_assoc($q)){

    $feedback = !empty($r['feedback']) ? $r['feedback'] : 'No Feedback';
    $review   = !empty($r['feedback_text']) ? $r['feedback_text'] : '-';

    // 🎯 Status color (optional but nice)
    if($r['status']=='pending') $status="<span style='color:orange;'>Pending</span>";
    elseif($r['status']=='approved') $status="<span style='color:blue;'>Approved</span>";
    elseif($r['status']=='completed') $status="<span style='color:green;'>Completed</span>";
    else $status="<span style='color:red;'>Rejected</span>";
?>

<tr>
<td><?php echo $r['name']; ?></td>
<td><?php echo $r['vehicle_name']; ?></td>
<td><?php echo $r['booking_date']; ?></td>
<td><?php echo $status; ?></td>

<td>
<?php
if($r['status'] == 'pending'){
?>
    <a class="btn btn-approve" href="update_booking_status.php?id=<?php echo $r['id']; ?>&status=approved">Approve</a>
    <a class="btn btn-reject" href="update_booking_status.php?id=<?php echo $r['id']; ?>&status=rejected">Reject</a>
<?php
}
elseif($r['status'] == 'approved'){
?>
    <a class="btn btn-complete" href="update_booking_status.php?id=<?php echo $r['id']; ?>&status=completed">Complete</a>
<?php
}
else{
    echo "-";
}
?>
</td>

<td><?php echo $feedback; ?></td>
<td><?php echo $review; ?></td>

</tr>

<?php } ?>

</table>
</div>

<?php include("footer.php"); ?>