<?php
include("includes/db.php");
include("includes/auth.php");
include("includes/functions.php");

redirectIfLoggedIn();
?>

<link rel="stylesheet" href="assets/css/style.css">

<div class="card" style="max-width:400px;margin:50px auto;">
<h2>Register</h2>

<?php displayMessage(); ?>

<form method="post">
    <input type="text" name="name" placeholder="Name" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="text" name="phone" placeholder="Phone">
    <input type="password" name="password" placeholder="Password" required>
    <button class="btn btn-add" name="register">Register</button>
</form>

<?php
if(isset($_POST['register'])){
    $name = clean($conn, $_POST['name']);
    $email = clean($conn, $_POST['email']);
    $phone = clean($conn, $_POST['phone']);
    $password =$_POST['password'];

    /* Check email exists */
    $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    
    if(mysqli_num_rows($check) > 0){
        setMessage("Email already exists","error");
    } else {
        mysqli_query($conn, "INSERT INTO users(name,email,phone,password)
        VALUES('$name','$email','$phone','$password')");

        setMessage("Registration Successful");
        redirect("login.php");
    }
}
?>

<p>Already have account? <a href="login.php">Login</a></p>
</div>