<?php

/* Sanitize Input */
function clean($conn, $data) {
    return mysqli_real_escape_string($conn, trim($data));
}

/* Redirect */
function redirect($url) {
    header("Location: $url");
    exit();
}

/* Get all data */
function getAll($conn, $table) {
    return mysqli_query($conn, "SELECT * FROM $table");
}

/* Get single row */
function getById($conn, $table, $id) {
    return mysqli_query($conn, "SELECT * FROM $table WHERE id=$id");
}

/* Count rows */
function countData($conn, $table) {
    $q = mysqli_query($conn, "SELECT * FROM $table");
    return mysqli_num_rows($q);
}

/* Show message */
function setMessage($msg, $type="success") {
    $_SESSION['msg'] = $msg;
    $_SESSION['msg_type'] = $type;
}

function displayMessage() {
    if(isset($_SESSION['msg'])){
        echo "<p style='color:" . ($_SESSION['msg_type']=='error' ? 'red' : 'green') . ";'>
        ".$_SESSION['msg']."</p>";
        unset($_SESSION['msg'], $_SESSION['msg_type']);
    }
}

/* Check duplicate booking */
function isDuplicateBooking($conn, $user_id, $vehicle_id, $date, $time){
    $q = mysqli_query($conn, "SELECT * FROM test_drive_bookings 
    WHERE user_id='$user_id' AND vehicle_id='$vehicle_id' 
    AND booking_date='$date' AND booking_time='$time'");
    
    return mysqli_num_rows($q) > 0;
}
?>