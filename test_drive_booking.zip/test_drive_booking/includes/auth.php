<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* Check if user logged in */
function checkUser() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: ../login.php");
        exit();
    }
}

/* Check if admin */
function checkAdmin() {
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
        header("Location: ../login.php");
        exit();
    }
}

/* Redirect if already logged in (for login/register page) */
function redirectIfLoggedIn() {
    if (isset($_SESSION['user_id'])) {
        if ($_SESSION['role'] == 'admin') {
            header("Location: admin/dashboard.php");
        } else {
            header("Location: user/index.php");
        }
        exit();
    }
}
?>