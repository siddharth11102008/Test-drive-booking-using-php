<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "test_drive_booking";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Database Connection Failed: " . mysqli_connect_error());
}

/* Set charset (important) */
mysqli_set_charset($conn, "utf8mb4");
?>