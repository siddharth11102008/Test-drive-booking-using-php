<?php
include("includes/db.php");
include("includes/auth.php");
include("includes/functions.php");

redirectIfLoggedIn();
?>

<link rel="stylesheet" href="assets/css/style.css">

<div class="card" style="max-width:400px;margin:50px auto;">
<h2>Login</h2>

<?php displayMessage(); ?>

<form method="post">
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <button class="btn btn-add" name="login">Login</button>
</form>

<?php
if(isset($_POST['login'])){
    $email = clean($conn, $_POST['email']);
    $password = $_POST['password'];

    $q = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    $user = mysqli_fetch_assoc($q);

    if($password == $user['password']){
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['role'] = $user['role'];

        setMessage("Login Successful");

        if($user['role'] == 'admin'){
            redirect("admin/dashboard.php");
        } else {
            redirect("user/index.php");
        }
    } else {
        setMessage("Invalid Email or Password","error");
    }
}
?>

<p>Don't have account? <a href="register.php">Register</a></p>
</div>