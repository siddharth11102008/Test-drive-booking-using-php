<?php
include("includes/db.php");
include("includes/functions.php");
?>

<link rel="stylesheet" href="assets/css/style.css">

<div class="card" style="max-width:500px;margin:50px auto;">
<h2>Contact Us</h2>

<?php displayMessage(); ?>

<form method="post">
    <input type="text" name="name" placeholder="Name" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="text" name="phone" placeholder="Phone">
    <textarea name="message" placeholder="Message"></textarea>
    <button class="btn btn-add" name="send">Send</button>
</form>

<?php
if(isset($_POST['send'])){
    $name = clean($conn, $_POST['name']);
    $email = clean($conn, $_POST['email']);
    $phone = clean($conn, $_POST['phone']);
    $msg = clean($conn, $_POST['message']);

    mysqli_query($conn, "INSERT INTO contact_requests(name,email,phone,message)
    VALUES('$name','$email','$phone','$msg')");

    setMessage("Message Sent Successfully");
}
?>
</div>