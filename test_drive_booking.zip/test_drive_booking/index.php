<link rel="stylesheet" href="assets/css/style.css">

<div class="card" style="max-width:500px;margin:80px auto;text-align:center;">
    <h2>🚗 Test Drive Booking System</h2>
    <p>Book your test drive easily and quickly.</p>

    <br>

    <a class="btn btn-add" href="login.php">Login</a>
    <a class="btn btn-edit" href="register.php">Register</a>
    <a class="btn btn-approve" href="contact.php">Contact</a>
</div>